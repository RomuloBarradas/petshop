# -*- coding: utf-8 -*-
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.core import serializers
import json

from django.db import connection

# Create your views here.
@login_required
def index_home(request):
	context = {
		'titulo_view': 'Inicial',
		'titulo': 'Seja Bem Vindo',
	}
	return render(request, 'home/index-home.html', context)
