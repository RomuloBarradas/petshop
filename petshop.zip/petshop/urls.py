"""petshop URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include

from petshop.acesso import urls as urls_acesso
from petshop.home import urls as urls_home
from petshop.pets import urls as urls_pets

urlpatterns = [
    path('', include(urls_acesso, namespace='acesso')),
    path('home/', include(urls_home, namespace='home')),
    path('pets/', include(urls_pets, namespace='pets')),
    path('admin/', admin.site.urls),
]
