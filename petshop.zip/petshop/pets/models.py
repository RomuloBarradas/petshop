from django.db import models

# Create your models here.
class Pet(models.Model):
	pet = models.CharField(max_length=35)
	raca = models.CharField(max_length=35)
	dono = models.CharField(max_length=35)

	def __str__(self):
		return 'Pet: {0}'.format(self.pet)