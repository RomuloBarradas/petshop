from django.urls import path

from . import views

app_name = 'pets'
urlpatterns = [
	path('', views.index_pets, name='index_pets'),
	path('adicionar/', views.add_pet, name='add_pet'),
	path('listar/', views.listar_pet, name='listar_pet'),
	path('deletar/', views.delete_pet, name='delete_pet'),
]
