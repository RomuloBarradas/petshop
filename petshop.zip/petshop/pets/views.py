# -*- coding: utf-8 -*-
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.core import serializers
import json

from django.db import connection

from petshop.pets.forms import PetForm
from petshop.pets.models import Pet

# Create your views here.
@login_required
def index_pets(request):
	context = {
		'titulo_view': 'Pets',
		'titulo': 'Seja Bem Vindo',
		'PetForm': PetForm,
	}
	return render(request, 'pets/index-pets.html', context)

@csrf_exempt
def add_pet(request):
	msg = ''
	success = False
	if request.method == 'POST':
		id = request.POST['pet_id']

		#Edita dados
		if id:
			resultado = Pet.objects.get(pk = id)
			form = PetForm(request.POST, instance=resultado)

			if form.is_valid():
				form.save()
				success = True
				msg = 'Pet Atualizado!'
			else:
				msg = 'Erro ao atualizar o pet!'
				print(form.errors)
		#Inserir dados
		else:
			form = PetForm(request.POST)

			if form.is_valid():
				pet = form.save()
				pet.save()
				success = True
				msg = 'Pet adicionado!'
			else:
				msg = 'Erro na adição do pet!'
				print(form.errors)

	return HttpResponse(json.dumps({'success': success, 'msg':msg}))

@csrf_exempt
def listar_pet(request):
	row = ''
	strWhere = ''
	pet = request.POST['pet_id']

	if pet:
		pets = Pet.objects.filter(pk=pet)
	else:
		pets = Pet.objects.all().order_by('pet')

	data = serializers.serialize('json', pets)
	return HttpResponse(data, content_type='application/json')

@csrf_exempt
def delete_pet(request):
	msg = ''
	success = False
	if request.method == 'POST':
		id = request.POST['delete_pet_id']
		pet = Pet.objects.get(pk = id)
		
		try:
			pet.delete()
			msg = 'Pet deletado!'
			success = True
		except Exception as e:
			if 'protected foreign key' in str(e):
				msg = 'Exclusão impedida por foreign key em uso!'
			else:
				msg = 'Falha na exclusão do pet!'
			
	return HttpResponse(json.dumps({'success': success, 'msg':msg}))