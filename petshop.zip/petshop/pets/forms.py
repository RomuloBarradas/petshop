from django import forms

from petshop.pets.models import Pet

class PetForm(forms.ModelForm):
	class Meta:
		model = Pet
		fields = (
			'pet',
			'raca',
			'dono'
		)