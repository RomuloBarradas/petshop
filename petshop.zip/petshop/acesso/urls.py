from django.urls import path

from . import views

app_name = 'acesso'
urlpatterns = [
	path('', views.index_acesso, name='index_acesso'),
	path('user-login', views.user_login, name='user_login'),
	path('user-logout', views.user_logout, name='user_logout'),
]
