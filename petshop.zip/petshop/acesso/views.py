# -*- coding: utf-8 -*-
from django.shortcuts import render, redirect
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate, login, logout
import os
from django.conf import settings
from django.http import HttpResponse
from django.core import serializers
import json

from django.contrib.auth.models import User

# Create your views here.
def index_acesso(request):
	context = {
		'titulo': 'Login - PetShop',
	}
	return render(request, 'acesso/index-acesso.html', context)

@csrf_exempt
def user_login(request):
	msg  = ''
	usuario = []
	success = False
	if request.method == 'POST':
		request.session.set_expiry(12000)
		username = request.POST.get('username')
		password = request.POST.get('password')

		user = authenticate(username=username, password=password)
		if user:
			# Procurando por usuarios com este login
			usuario = User.objects.filter(username=username)
			if usuario:
				# Altenticando usuario selecionado
				# Verificando se usuario esta ativo
				if user.is_active:
					# Criando sessoes
					request.session['nome'] = user.first_name
					request.session['sobrenome'] = user.last_name
					request.session['email'] = user.email
					request.session['usuario_id'] = user.pk
					request.session['usuario']  = user.username
					request.session['superuser'] = user.is_superuser

					login(request, user)
					success = True
					msg =  "usuario_autorizado"
				else:
					msg =  "Usuário inativo no sistema!"
			else:
				msg = "Você não tem privilegio de acesso!"
		else:
			msg = "Usuário ou senha invalido!"
		return HttpResponse(json.dumps({'success': success, 'msg':msg}))

def user_logout(request):
	msg = ''
	try:
		request.session.flush()
		logout(request)
	except KeyError:
		msg = 'Não conseguiu deletar a sessão.'

	return redirect(reverse("acesso:index_acesso"))
