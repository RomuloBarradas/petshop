from django.apps import AppConfig


class AcessoConfig(AppConfig):
    name = 'acesso'
